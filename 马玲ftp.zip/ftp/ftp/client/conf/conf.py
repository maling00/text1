configuration={
    "server_ip":"127.0.0.1",
    "server_port":"8080",
    


}