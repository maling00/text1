configuration={
    "server_ip":"127.0.0.1",
    "server_port":8080,
    "coding":"utf-8",
    "block_size":1024,
}